package interfaces;
public interface Printable {
    void print();
}