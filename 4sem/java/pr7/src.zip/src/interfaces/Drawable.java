package interfaces;
public interface Drawable {
    void draw();
}
